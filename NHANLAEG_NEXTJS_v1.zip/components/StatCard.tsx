export function StatCard({ title, value }: { title: string; value: string | number }) {
  return (
    <div className="card border-l-4 border-l-gold p-5">
      <div className="text-sm text-black/55">{title}</div>
      <div className="mt-2 text-3xl font-black text-forest">{value}</div>
    </div>
  );
}
