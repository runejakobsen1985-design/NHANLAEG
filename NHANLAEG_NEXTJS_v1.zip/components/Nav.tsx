import Link from "next/link";

const items = [
  ["Dashboard", "/"],
  ["Kunder", "/customers"],
  ["Opgaver", "/jobs"],
  ["Medarbejdere", "/employees"],
  ["Faktura", "/invoices"],
  ["Indstillinger", "/settings"],
];

export function Nav() {
  return (
    <nav className="sticky top-0 z-20 border-b border-black/10 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl gap-2 overflow-x-auto px-4 py-3">
        {items.map(([label, href]) => (
          <Link key={href} href={href} className="whitespace-nowrap rounded-full bg-sand px-4 py-2 text-sm font-bold text-forest">
            {label}
          </Link>
        ))}
      </div>
    </nav>
  );
}
