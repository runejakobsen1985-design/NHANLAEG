export function Header() {
  return (
    <header className="bg-forest text-white">
      <div className="mx-auto max-w-6xl px-4 py-5">
        <div className="text-2xl font-black tracking-tight">NHANLÆG</div>
        <div className="text-sm text-white/75">Driftssystem til Nordisk Have & Anlæg</div>
      </div>
    </header>
  );
}
