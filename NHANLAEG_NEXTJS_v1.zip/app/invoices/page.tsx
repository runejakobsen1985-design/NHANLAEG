export default function InvoicesPage() {
  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-black text-forest">Fakturagrundlag</h1>
      <div className="card overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-forest text-white">
            <tr>
              <th className="p-3">Kunde</th>
              <th className="p-3">Opgave</th>
              <th className="p-3">Beløb</th>
              <th className="p-3">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="p-3 text-black/60" colSpan={4}>Ingen fakturaer endnu.</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
