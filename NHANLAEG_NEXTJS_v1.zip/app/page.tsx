import { StatCard } from "@/components/StatCard";
import Link from "next/link";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <section className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-forest">Dashboard</h1>
          <p className="mt-1 text-black/60">Overblik over dagens drift.</p>
        </div>
        <Link href="/jobs" className="btn btn-primary">+ Ny opgave</Link>
      </section>

      <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard title="Aktive kunder" value="0" />
        <StatCard title="Åbne opgaver" value="0" />
        <StatCard title="Udført" value="0" />
        <StatCard title="Klar til faktura" value="0" />
      </section>

      <section className="card p-5">
        <h2 className="text-xl font-black text-forest">Dagens opgaver</h2>
        <p className="mt-3 text-black/60">Ingen opgaver endnu. Opret den første opgave under Opgaver.</p>
      </section>

      <section className="grid gap-3 md:grid-cols-3">
        <Link href="/customers" className="card p-5 font-bold text-forest">+ Ny kunde</Link>
        <Link href="/jobs" className="card p-5 font-bold text-forest">+ Ny opgave</Link>
        <Link href="/invoices" className="card p-5 font-bold text-forest">Fakturagrundlag</Link>
      </section>
    </div>
  );
}
