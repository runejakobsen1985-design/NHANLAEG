export default function SettingsPage() {
  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-black text-forest">Indstillinger</h1>
      <div className="card p-5">
        <p className="text-black/70">
          Tilføj disse miljøvariabler i Vercel:
        </p>
        <pre className="mt-4 overflow-auto rounded-xl bg-black p-4 text-sm text-white">
NEXT_PUBLIC_SUPABASE_URL=https://wxoofstjmihsbgtbyhih.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=din_publishable_key
        </pre>
      </div>
    </div>
  );
}
