export default function JobsPage() {
  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-black text-forest">Opgaver</h1>
      <div className="card p-5">
        <form className="grid gap-3">
          <input className="input" placeholder="Titel" />
          <textarea className="input min-h-28" placeholder="Beskrivelse" />
          <select className="input">
            <option>Planlagt</option>
            <option>I gang</option>
            <option>Udført</option>
            <option>Klar til faktura</option>
          </select>
          <input className="input" type="date" />
          <input className="input" type="number" placeholder="Pris" />
          <button className="btn btn-primary" type="button">Gem opgave</button>
        </form>
      </div>
    </div>
  );
}
