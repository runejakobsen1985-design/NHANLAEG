import "./globals.css";
import type { Metadata } from "next";
import { Header } from "@/components/Header";
import { Nav } from "@/components/Nav";

export const metadata: Metadata = {
  title: "NHANLÆG",
  description: "Driftssystem til Nordisk Have & Anlæg",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="da">
      <body>
        <Header />
        <Nav />
        <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
