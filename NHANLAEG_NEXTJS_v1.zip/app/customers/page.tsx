export default function CustomersPage() {
  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-black text-forest">Kunder</h1>
      <div className="card p-5">
        <form className="grid gap-3 md:grid-cols-2">
          <input className="input" placeholder="Kundenavn" />
          <input className="input" placeholder="Telefon" />
          <input className="input md:col-span-2" placeholder="Adresse" />
          <input className="input" placeholder="Email" />
          <input className="input" placeholder="CVR" />
          <button className="btn btn-primary md:col-span-2" type="button">Gem kunde</button>
        </form>
      </div>
    </div>
  );
}
