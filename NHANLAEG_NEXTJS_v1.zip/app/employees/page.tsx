export default function EmployeesPage() {
  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-black text-forest">Medarbejdere</h1>
      <div className="card p-5">
        <form className="grid gap-3 md:grid-cols-2">
          <input className="input" placeholder="Navn" />
          <input className="input" placeholder="Telefon" />
          <input className="input" placeholder="Email" />
          <input className="input" placeholder="Rolle" />
          <button className="btn btn-primary md:col-span-2" type="button">Gem medarbejder</button>
        </form>
      </div>
    </div>
  );
}
