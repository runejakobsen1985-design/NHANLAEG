# Nordisk Have & Anlæg – V10.5 PRINT REPARERET

Fejlårsag:
En gammel V7.5 print-reparation lyttede på alle klik i capture-fasen.
Når en knap indeholdt teksten Print eller Udskriv, kunne den stoppe klikket
med stopImmediatePropagation(), før dokumentets egen printfunktion blev kørt.

Rettelse:
- v75PrintRepairScript er fjernet.
- v75PrintRepairStyles er fjernet.
- Der er ikke tilføjet en ny global klik-opfanger.
- Hvert dokument bruger igen sin egen eksisterende printfunktion.
- Dokumentdesign og printlayout er ikke ændret.

Bevaret:
- arbejdssedler
- kontrakter og serviceaftaler
- samarbejdsaftaler
- tilbud og e-conomic
- kørsel
- udgifter
- kundehistorik
- ugeplan og kalender
- dokumentnumre
- Ledelse-only
